# -*- coding: utf-8 -*-
import decimal
from datetime import datetime
from odoo import models, fields, api, _
import base64
import xlwt
from io import BytesIO
from odoo.tools.translate import translate, _


def _decimal_format(num):
    return num if num else 0


# 成本项目分摊汇总（新）表
class HrpCostApportionUnitXlsReport(models.TransientModel):
    _name = "hrp.cost.apportion.unit.xls.report"
    _description = 'Hrp Cost Apportion Unit Xls Report'

    file = fields.Binary('文件')

    def generate_xlsx_report(self, execl_data, objects):

        wb = xlwt.Workbook(encoding='utf-8')
        # 标题头-居中
        title_format_center = xlwt.XFStyle()  # 初始化样式
        title_font = xlwt.Font()  # 为样式创建字体
        title_font.name = '宋体'  # 字体
        title_font.bold = True  # 加粗
        title_font.height = 34 * 12  # 字体大小
        title_format_center.font = title_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER  # 居中显示
        title_format_center.alignment = alignment

        # 标题头-居左
        title_format_left = xlwt.XFStyle()  # 初始化样式
        title_font = xlwt.Font()  # 为样式创建字体
        title_font.name = '宋体'  # 字体
        title_font.bold = True  # 加粗
        title_font.height = 34 * 12  # 字体大小
        title_format_left.font = title_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT  # 居左显示
        title_format_left.alignment = alignment

        twelve_bold_format_left = xlwt.XFStyle()  # 初始化样式
        twelve_font = xlwt.Font()  # 为样式创建字体
        twelve_font.name = '宋体'  # 字体
        twelve_font.bold = True  # 加粗
        twelve_font.height = 22 * 11  # 字体大小
        twelve_bold_format_left.font = twelve_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT  # 居左显示
        twelve_bold_format_left.alignment = alignment

        twelve_bold_format_center = xlwt.XFStyle()  # 初始化样式
        twelve_font = xlwt.Font()  # 为样式创建字体
        twelve_font.name = '宋体'  # 字体
        twelve_font.bold = True  # 加粗
        twelve_font.height = 22 * 11 # 字体大小
        twelve_bold_format_center.font = twelve_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER  # 居中显示
        twelve_bold_format_center.alignment = alignment

        twelve_bold_format_right = xlwt.XFStyle()  # 初始化样式
        twelve_font = xlwt.Font()  # 为样式创建字体
        twelve_font.name = '宋体'  # 字体
        twelve_font.bold = True  # 加粗
        twelve_font.height = 22 * 11  # 字体大小
        twelve_bold_format_right.font = twelve_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_RIGHT  # 居右显示
        twelve_bold_format_right.alignment = alignment

        ten_bold_format_center = xlwt.XFStyle()  # 初始化样式
        ten_font = xlwt.Font()  # 为样式创建字体
        ten_font.name = '宋体'  # 字体
        ten_font.bold = True  # 加粗
        ten_font.height = 20 * 11  # 字体大小 10号
        ten_bold_format_center.font = ten_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER  # 居中显示
        ten_bold_format_center.alignment = alignment

        ten_simple_format_center = xlwt.XFStyle()  # 初始化样式
        ten_font = xlwt.Font()  # 为样式创建字体
        ten_font.name = '宋体'  # 字体
        ten_font.bold = False  # 不加粗
        ten_font.height = 20 * 11  # 字体大小 10号
        ten_simple_format_center.font = ten_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER  # 居中显示
        ten_simple_format_center.alignment = alignment
        ten_simple_format_center.num_format_str = '#,##0.00'

        ten_simple_format_left = xlwt.XFStyle()  # 初始化样式
        twelve_font = xlwt.Font()  # 为样式创建字体
        twelve_font.name = '宋体'  # 字体
        twelve_font.bold = False  # 加粗
        twelve_font.height = 20 * 11  # 字体大小
        ten_simple_format_left.font = twelve_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT  # 居左显示
        ten_simple_format_left.alignment = alignment

        ten_bold_format_left = xlwt.XFStyle()  # 初始化样式
        twelve_font = xlwt.Font()  # 为样式创建字体
        twelve_font.name = '宋体'  # 字体
        twelve_font.bold = True  # 加粗
        twelve_font.height = 20 * 11  # 字体大小
        ten_bold_format_left.font = twelve_font  # 为样式设置字体
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT  # 居左显示
        ten_bold_format_left.alignment = alignment

        # 加边框
        borders = xlwt.Borders()  # Create Borders
        borders.left = 1
        borders.right = 1
        borders.top = 1
        borders.bottom = 1
        title_format_center.borders = borders
        title_format_left.borders = borders
        twelve_bold_format_left.borders = borders
        twelve_bold_format_center.borders = borders
        twelve_bold_format_right.borders = borders
        ten_bold_format_center.borders = borders
        ten_simple_format_center.borders = borders
        ten_simple_format_left.borders = borders
        ten_bold_format_left.borders = borders

        report_name = _('成本项目分摊汇总表')

        # 打印标题
        # set sheet name
        ws = wb.add_sheet(report_name)
        ws.col(0).width = (25 * 367)  # 设置表格的宽度
        ws.col(1).width = (15 * 367)
        ws.col(2).width = (15 * 367)
        ws.col(3).width = (15 * 367)
        ws.col(4).width = (15 * 367)
        ws.col(5).width = (15 * 367)
        row = 0
        # ws.set_row(row, 28)
        ws.write_merge(row, row, 0, 5, report_name, title_format_center)

        # 打印子标题
        row += 1
        # ws.set_row(row, 24)
        ws.write_merge(row, row, 0, 5, _('Hospital Cost C5-03 Report'), twelve_bold_format_right)

        row += 1
        # ws.set_row(row, 24)
        ws.write_merge(row, row, 0, 1, _('Organization Unit:') + objects.company_id.name, twelve_bold_format_left)
        ws.write_merge(row, row, 2, 3,
                       objects.period_id.code[3:7] + _('Year') + objects.period_id.code[0:2] + _('Month'),
                       twelve_bold_format_center)
        ws.write_merge(row, row, 4, 5, _('Unit: Yuan'), twelve_bold_format_right)

        # 打印表头
        row += 1
        # ws.set_row(row, 33)
        ws.write(row, 0, _('Cost Unit'), ten_bold_format_center)
        ws.write(row, 1, _('Direct In Direct Cost'), ten_bold_format_center)
        ws.write(row, 2, _('Public Costs'), ten_bold_format_center)
        ws.write(row, 3, _('Management Dept Cost'), ten_bold_format_center)
        ws.write(row, 4, _('Administration Dept Cost'), ten_bold_format_center)
        ws.write(row, 5, _('Medical Assist Dept Cost'), ten_bold_format_center)

        # 设置表格列宽
        # ws.set_column(0, 0, 30)
        # ws.set_column(1, 5, 18)

        row += 1
        # ws.set_row(row, 16.5)
        for data in execl_data:
            if data['name'] == 'cost_unit_total':
                ws.write(row, 0, _('Total'), ten_bold_format_left)
            else:
                ws.write(row, 0, data['name'], ten_simple_format_left)
            ws.write(row, 1, _decimal_format(data['direct_calculate_cost']), ten_simple_format_center)
            ws.write(row, 2, _decimal_format(data['public_cost']), ten_simple_format_center)
            ws.write(row, 3, _decimal_format(data['admin_cost']), ten_simple_format_center)
            ws.write(row, 4, _decimal_format(data['medical_assist_cost']), ten_simple_format_center)
            ws.write(row, 5, _decimal_format(data['medical_tech_cost']), ten_simple_format_center)
            # ws.set_row(row, 16.5)
            row += 1

        # 写脚
        # ws.set_row(row, 26)
        ws.write_merge(row, row, 0, 1, _('Unit Leader:'), title_format_left)
        ws.write_merge(row, row, 2, 3, _('Finance Supervisor:'), title_format_left)
        ws.write_merge(row, row, 4, 5, _('Lister:'), title_format_left)

        buffer = BytesIO()
        wb.save(buffer)
        return base64.encodebytes(buffer.getvalue())

    @api.multi
    def action_export_data(self, lines, params):

        res = self.create({'file': self.generate_xlsx_report(lines, params)})

        value = dict(
            type='ir.actions.act_url',
            target='new',
            url='/web/content?model=%s&id=%s&field=file&download=true&filename=成本项目分摊汇总表.xls' % (self._name, res.id),
        )
        return value
