# -*- coding: utf-8 -*-

##############################################################################
#
#    该文件为：成本项目分摊汇总表（新）
#    优化报表：从分摊明细进行期间汇总的基础表取值
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import except_orm


# 成本项目分摊汇总表（新）
class HrpCostUnitApprotionSummaryQueryReport(models.TransientModel):
    _name = 'hrp.cost.unit.approtion.summary.report'
    _description = 'Approtion Cost Unit Summary'

    def _get_allocation(self):
        allocation_obj = self.env['hrp.cost.allocation.setting']
        allocation_ids = allocation_obj.search(
            [('company_id', '=', self.env.user.company_id.id)]
        )
        if len(allocation_ids) == 1:
            return allocation_ids[0]

    def _get_period(self):
        today = fields.Date.today()
        period_ids = self.env['dy.fin.account.period'].find(today)
        if period_ids:
            return period_ids[0]

    # def init_unit_level(self):
    #     lines = self.env['hrp.cost.sub.cost.unit'].search([])
    #     for line in lines:
    #         temp = line
    #         level = 1
    #         while temp.parent_id:
    #             temp = self.env['hrp.cost.sub.cost.unit'].browse([(temp.parent_id.id)])
    #             level += 1
    #         sql1 = "UPDATE hrp_cost_sub_cost_unit SET unit_level = %s WHERE id = %s " % (level, line.id)
    #         self.env.cr.execute(sql1)
    #     return

    # 公司
    company_id = fields.Many2one(comodel_name="res.company", string="Company", help="Company", required=True,
                                 default=lambda self: self.env.user.company_id)
    # 分摊结构
    allocation_id = fields.Many2one(comodel_name="hrp.cost.allocation.setting", string="Apportion Structure",
                                    help="Apportion Structure Name", required=True, default=_get_allocation)
    # 期间
    period_id = fields.Many2one('dy.fin.account.period', string='Period', required=True, default=_get_period)
    # 输出格式
    output_format = fields.Selection([('pdf', 'PDF'), ('excel', 'EXCEL')], default='excel',
                                     string="Output Format",
                                     help="Output Format", required=True)
    # 成本维度
    cost_dimension = fields.Selection([('costunit', 'Cost Unit'), ('subcostunit', 'Sub Cost Unit')], default='costunit',
                                      string="Cost Dimension", help="Cost Dimension", required=True)
    # 成本项目行
    cost_unit_ids = fields.One2many(comodel_name='hrp.cost.approtion.sumquery.cost.unit',
                                    inverse_name="cu_apps_query_id", string='Cost Unit', help="Cost Unit")
    # 成本子项行
    sub_cost_unit_ids = fields.One2many(comodel_name='hrp.cost.approtion.sumquery.sub.cost.unit',
                                        inverse_name="scu_apps_query_id", string='Sub Cost Unit',
                                        help="Sub Cost Unit")

    @api.multi
    def report_print(self):
        l_deatils = []
        if self.cost_dimension == 'costunit':
            for l_cost_unit in self.cost_unit_ids:
                l_deatils.append(l_cost_unit.cost_unit_id.id)
        if self.cost_dimension == 'subcostunit':
            for l_sub_cost_unit in self.sub_cost_unit_ids:
                l_deatils.append(l_sub_cost_unit.sub_cost_unit_id.id)

        params = {
            'context': self.env.context,
            'company_id': self.company_id.id,
            'allocation_id': self.allocation_id.id,
            'allocation_name': self.company_id.name + '-' + self.allocation_id.name,
            'period_id': self.period_id.id,
            'period_name': self.period_id.name,
            'cost_dimension': self.cost_dimension,
            'details': tuple(l_deatils)
        }
        excel_data = self.get_excel_datas(params)

        return self.env['hrp.cost.apportion.unit.xls.report'].action_export_data(excel_data, self)

    @api.model
    def get_excel_datas(self, params):
        period_id = params['period_id']
        company_id = params['company_id']
        allocation_id = params['allocation_id']
        cost_dimension = params['cost_dimension']
        # 分摊结构 + 公司 + 期间下是否存在分摊结果
        allocation_result = self.env['hrp.cost.apportion.costdata'].search(
            [('period_id', '=', period_id), ('company_id', '=', company_id), ('allocation_id', '=', allocation_id)])
        try:
            first_allocation = allocation_result[0]
        except IndexError:
            raise except_orm(
                _('No Result Match'),
                _('There is no apportionment result.')
            )

        # 获取数据
        # 选择的是成本项目
        excel_data = []
        if cost_dimension == 'costunit':
            excel_data = self.get_cost_unit_excel_datas(params)
        # 选择的是成本子项
        if cost_dimension == 'subcostunit':
            excel_data = self.get_sub_cost_unit_excel_datas(params)
        return excel_data

    # 获得成本项目维度数据
    @api.model
    def get_cost_unit_excel_datas(self, params):
        period_id = params['period_id']
        company_id = params['company_id']
        allocation_id = params['allocation_id']
        cost_unit_ids = params['details']

        sql1 = """
            SELECT
                cost_unit_id,
                hccu. NAME,
                hccu.code,
                0 as unit_level,
                direct_calculate_cost,
                public_cost,
                admin_cost,
                medical_assist_cost,
                medical_tech_cost
            FROM
                hrp_cost_unit_dimension_table hcudt,
                hrp_cost_cost_unit hccu
            WHERE
                hcudt.cost_unit_id = hccu. ID
            AND hcudt.period_id = %s
            AND hcudt.company_id = %s
            AND hcudt.cost_allocation_id = %s
        """
        sql2 = """
            AND hccu.ID IN %s
            """
        sql3 = """
            ORDER BY
                CAST (hccu.code AS INTEGER)
        """

        # 选择了某几个成本项目
        if cost_unit_ids:
            self.env.cr.execute(sql1 + sql2 + sql3, [period_id, company_id, allocation_id, cost_unit_ids])
            results = self.env.cr.dictfetchall()
        else:
            self.env.cr.execute(sql1 + sql3, [period_id, company_id, allocation_id])
            results = self.env.cr.dictfetchall()
            # 加合计行
            direct_calculate_cost = 0
            public_cost = 0
            admin_cost = 0
            medical_assist_cost = 0
            medical_tech_cost = 0
            for rt in results:
                direct_calculate_cost += rt['direct_calculate_cost'] if rt['direct_calculate_cost'] else 0
                public_cost += rt['public_cost'] if rt['public_cost'] else 0
                admin_cost += rt['admin_cost'] if rt['admin_cost'] else 0
                medical_assist_cost += rt['medical_assist_cost'] if rt['medical_assist_cost'] else 0
                medical_tech_cost += rt['medical_tech_cost'] if rt['medical_tech_cost'] else 0
            results.append({
                'name': 'cost_unit_total',
                'direct_calculate_cost': direct_calculate_cost,
                'public_cost': public_cost,
                'admin_cost': admin_cost,
                'medical_assist_cost': medical_assist_cost,
                'medical_tech_cost': medical_tech_cost
            })
        return results

    # 获得成本子项维度数据
    @api.model
    def get_sub_cost_unit_excel_datas(self, params):
        # 当选择的成本维度=成本子项，且查询界面选择了一个或多个成本子项时，只显示选择的成本子项的成本数据（若选择的成本子项为父级，
        # 则同时展示其所有下级成本子项的成本数据）
        # 若查询界面未选择成本子项，则显示所有成本子项（包括成本项目）的成本数据
        if params['details']:
            results = self.get_some_sub_unit_data(params)
        else:
            results = self.get_all_unit_data(params)
        return results

    # 获得选中的成本子项数据
    @api.model
    def get_some_sub_unit_data(self, params):
        period_id = params['period_id']
        company_id = params['company_id']
        allocation_id = params['allocation_id']
        cost_unit_ids = params['details']
        # 获得成本子项id的所有子id
        sql_cu_childs = """
                    SELECT
                        ID
                    FROM
                        (
                            WITH RECURSIVE r AS (
                                SELECT
                                    *
                                FROM
                                    hrp_cost_sub_cost_unit
                                WHERE
                                    ID = %s
                                UNION ALL
                                    SELECT
                                        hrp_cost_sub_cost_unit.*
                                    FROM
                                        hrp_cost_sub_cost_unit,
                                        r
                                    WHERE
                                        hrp_cost_sub_cost_unit.parent_id = r. ID
                            ) SELECT * FROM r ORDER BY ID
                        ) T
                """
        cu_id_list = []
        for cost_unit_id in cost_unit_ids:
            if cost_unit_id in cu_id_list:
                continue
            self.env.cr.execute(sql_cu_childs, [cost_unit_id])
            tmp_cu_ids = self.env.cr.fetchall()
            for tmp_cu_id in tmp_cu_ids:
                cu_id_list.append(tmp_cu_id[0])
                # id 去重
        cu_ids = tuple(set(cu_id_list))
        sql_select_scu = """
            SELECT
                cost_sub_unit_id,
                hcscu. NAME,
                hcscu.code,
                hcscu.unit_level,
                hcscu.parent_id,
                direct_calculate_cost,
                public_cost,
                admin_cost,
                medical_assist_cost,
                medical_tech_cost
            FROM
                hrp_cost_sub_unit_dimension_table hcsudt,
                hrp_cost_sub_cost_unit hcscu
            WHERE
                hcsudt.cost_sub_unit_id = hcscu. ID
            AND hcsudt.period_id = %s
            AND hcsudt.company_id = %s
            AND hcsudt.cost_allocation_id = %s
            AND hcscu.id in %s
            ORDER BY
                code
        """
        self.env.cr.execute(sql_select_scu, [period_id, company_id, allocation_id, cu_ids])
        results = self.env.cr.dictfetchall()
        # 加空格 要考虑是不是顶级
        excel_datas = []
        for rt in results:
            level_datas = []
            tree_datas = []
            # 排除中间层级的成本子项
            if self.get_sub_cost_unit_id_is_topid(rt['cost_sub_unit_id'], cu_id_list):
                # tree排序
                level_datas.append(rt)
                tree_datas = self.get_tree_sub_cost_id_order(level_datas, results)
                # 给子集加缩进空格
                top_level = tree_datas[0]['unit_level']
                space = '    '
                for tree_d in tree_datas:
                    tree_d['name'] = space * (tree_d['unit_level'] - top_level) + tree_d['name']
                excel_datas += tree_datas
        return excel_datas

    # 判断成本子项id在cu_id_list里是不是顶级id
    @api.multi
    def get_sub_cost_unit_id_is_topid(self, cu_id, cu_id_list):
        cu_obj = self.env['hrp.cost.sub.cost.unit'].browse(cu_id)
        if cu_obj.parent_id:
            if cu_obj.parent_id.id in cu_id_list:
                return False
            else:
                return True
        else:
            return True

    # 递归顶级成本子项的所有层级子集 数据行 list
    @api.multi
    def get_tree_sub_cost_id_order(self, level_datas, datas):
        res = []
        for level_data in level_datas:
            res.append(level_data)
            level_child_datas = []
            for data in datas:
                if data['parent_id'] == level_data['cost_sub_unit_id']:
                    level_child_datas.append(data)
            res += self.get_tree_sub_cost_id_order(level_child_datas, datas)
        return res

    # 获得成本项目和子项目数据
    @api.model
    def get_all_unit_data(self, params):
        period_id = params['period_id']
        company_id = params['company_id']
        allocation_id = params['allocation_id']
        # 查成本项目
        sql_cost_unit = """
            SELECT
                cost_unit_id,
                hccu.name,
                hccu.code,
                0 as unit_level,
                direct_calculate_cost,
                public_cost,
                admin_cost,
                medical_assist_cost,
                medical_tech_cost
            FROM
                hrp_cost_unit_dimension_table hcudt,
                hrp_cost_cost_unit hccu
            WHERE
                hcudt.cost_unit_id = hccu. ID
            AND hcudt.period_id = %s
            AND hcudt.company_id = %s
            AND hcudt.cost_allocation_id = %s
            ORDER BY
                CAST (hccu.code AS INTEGER)
        """
        # 查成本子项目
        sql_sub_cost_unit = """
            SELECT
                cost_sub_unit_id,
                hcscu.name,
                hcscu.code,
                hcscu.unit_level,
                direct_calculate_cost,
                public_cost,
                admin_cost,
                medical_assist_cost,
                medical_tech_cost
            FROM
                hrp_cost_sub_unit_dimension_table hcsudt,
                hrp_cost_sub_cost_unit hcscu
            WHERE
                hcsudt.cost_sub_unit_id = hcscu. ID
            AND hcsudt.period_id = %s
            AND hcsudt.company_id = %s
            AND hcsudt.cost_allocation_id = %s
            AND hcscu.cost_unit = %s
            ORDER BY
                code
        """
        self.env.cr.execute(sql_cost_unit, [period_id, company_id, allocation_id])
        cost_unit_datas = self.env.cr.dictfetchall()
        # 计算合计行
        direct_calculate_cost = 0
        public_cost = 0
        admin_cost = 0
        medical_assist_cost = 0
        medical_tech_cost = 0
        results = []
        for cost_unit_data in cost_unit_datas:
            results.append(cost_unit_data)
            self.env.cr.execute(sql_sub_cost_unit,
                                [period_id, company_id, allocation_id, cost_unit_data['cost_unit_id']])
            sql_sub_cost_unit_datas = self.env.cr.dictfetchall()
            results += sql_sub_cost_unit_datas

            direct_calculate_cost += cost_unit_data['direct_calculate_cost'] if cost_unit_data['direct_calculate_cost'] else 0
            public_cost += cost_unit_data['public_cost'] if cost_unit_data['public_cost'] else 0
            admin_cost += cost_unit_data['admin_cost'] if cost_unit_data['admin_cost'] else 0
            medical_assist_cost += cost_unit_data['medical_assist_cost'] if cost_unit_data['medical_assist_cost'] else 0
            medical_tech_cost += cost_unit_data['medical_tech_cost'] if cost_unit_data['medical_tech_cost'] else 0
        # 给成本项目/子项加空格
        space = '    '
        for rt in results:
            rt['name'] = space * rt['unit_level'] + rt['name']
        # 加合计行
        results.append({
            'name': 'cost_unit_total',
            'direct_calculate_cost': direct_calculate_cost,
            'public_cost': public_cost,
            'admin_cost': admin_cost,
            'medical_assist_cost': medical_assist_cost,
            'medical_tech_cost': medical_tech_cost
        })
        return results


class HrpCostApprotionSumqueryCostCenter(models.TransientModel):
    _name = 'hrp.cost.approtion.sumquery.cost.unit'
    _description = 'Cost Unit for cost apportion summary query'

    cu_apps_query_id = fields.Many2one(comodel_name="hrp.cost.unit.approtion.summary.report")
    # 成本项目id
    cost_unit_id = fields.Many2one(comodel_name="hrp.cost.cost.unit", help="Cost Center", string="Cost Unit",
                                   domain="[('company_id', '=', parent.company_id)]")
    # 成本项目code
    cost_unit_code = fields.Char(comodel_name="hrp.cost.cost.unit", related="cost_unit_id.code",
                                 string="Cost Unit Code", help="Cost Unit Code", readonly=True)


class HrpCostApprotionSumqueryAnalyticUnit(models.TransientModel):
    _name = 'hrp.cost.approtion.sumquery.sub.cost.unit'
    _description = 'Sub Cost Unit for cost apportion summary query'

    # 头id
    scu_apps_query_id = fields.Many2one(comodel_name="hrp.cost.unit.approtion.summary.report")
    # 成本子项id
    sub_cost_unit_id = fields.Many2one(comodel_name="hrp.cost.sub.cost.unit", string="Sub Cost Unit",
                                       help="Sub Cost Unit",
                                       domain="[('company_id', '=', parent.company_id)]")
    # 成本子项code
    sub_cost_unit_code = fields.Char(comodel_name="hrp.cost.sub.cost.unit", string="Sub Cost Unit Code",
                                     help="Sub Cost Unit Code",
                                     related="sub_cost_unit_id.code")
